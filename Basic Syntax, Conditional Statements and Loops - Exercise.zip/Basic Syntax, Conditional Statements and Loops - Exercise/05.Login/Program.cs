﻿using System;


namespace _05.Login
{
    class Program
    {
        static void Main(string[] args)
        {
            string username = Console.ReadLine();

            //string password = string.Concat(username.Reverse());
            string password = "";
            for (int i = username.Length-1; i >= 0 ; i--)
            {
                password += username[i];
            }
            bool isLogedIn = false;
            bool isBlocked = false;
            int attemptCounter = 0;

            while (!isLogedIn && !isBlocked)
            {
                string inputPassword = Console.ReadLine();
                if (inputPassword == password)
                {
                    Console.WriteLine($"User {username} logged in.");
                    isLogedIn = true;
                }
                else
                {
                    attemptCounter += 1;

                    if (attemptCounter == 4)
                    {
                        Console.WriteLine($"User {username} blocked!");
                        isBlocked = true;
                    }
                    else
                    {
                        Console.WriteLine("Incorrect password. Try again.");
                    }
                }
            }
        }
    }
}
