﻿    using System;

    namespace _09.PadawanEquipment
    {
        class Program
        {
            static void Main(string[] args)
            {
                double budget = double.Parse(Console.ReadLine());
                int studentCount = int.Parse(Console.ReadLine());
                double lightsabersPrice = double.Parse(Console.ReadLine());
                double robesPrice = double.Parse(Console.ReadLine());
                double beltsPrice = double.Parse(Console.ReadLine());

                //10students = Math.Ceiling(10*1.1)

                int lightsabersCount = (int)Math.Ceiling(studentCount * 1.1);
                int beltsCount = studentCount - studentCount / 6;

                double totalPrice = lightsabersPrice * lightsabersCount +
                                   robesPrice * studentCount +
                                   beltsPrice * beltsCount;

                if (budget >= totalPrice)
                {
                    Console.WriteLine($"The money is enough - it would cost {totalPrice:F2}lv.");
                }
                else
                {
                    Console.WriteLine($"Ivan Cho will need {(totalPrice - budget):F2}lv more.");
                }

            }
        }
    }
