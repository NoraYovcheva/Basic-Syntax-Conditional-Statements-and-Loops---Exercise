﻿using System;

namespace _06.StrongNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int originNumbert = number;
            
            int sum = 0;

            while (number > 0)
            {
                int lastDigit = number % 10;
                int factorial = 1;

                //for (int i = lastDigit; i >= 1; i--)
                //{
                //    factorial *= i;
                //}
                for (int i = 1; i <= lastDigit; i++)
                {
                    factorial *= i;
                }
                sum += factorial;
                number /= 10;

                if (originNumbert == sum)
                {
                    Console.WriteLine("yes");
                }
                else
                {
                    Console.WriteLine("no");
                }
            }
        }
    }
}
