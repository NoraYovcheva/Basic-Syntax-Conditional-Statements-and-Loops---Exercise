﻿using System;

namespace _07.VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            double balance = 0;

            while (line != "Start")
            {
                double currentCoin = double.Parse(line);

                if (currentCoin == 0.10 ||
                    currentCoin == 0.20 ||
                    currentCoin == 0.50 ||
                    currentCoin == 1 ||
                    currentCoin == 2)
                {
                    balance += currentCoin;
                }
                else
                {
                    Console.WriteLine($"Cannot accept {currentCoin}” ");
                }

                line = Console.ReadLine();
            }

            line = Console.ReadLine();

            while (line != "End")
            {
                double price = 0;

                if (line == "Nuts")
                {
                    price = 2;
                }
                else if (line == "Water")
                {
                    price = 0.7;
                }
                else if (line == "Crisps")
                {
                    price = 1.5;
                }
                else if (line == "Soda")
                {
                    price = 0.8;
                }
                else if (line == "Coke")
                {
                    price = 1;
                }
                if (price != 0)
                {
                    if (balance >= price)
                    {
                        Console.WriteLine($"Purchased {line.ToLower()}");
                        balance -= price;
                    }
                    else
                    {
                        Console.WriteLine($"Sorry, not enough money");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid product");
                }
                line = Console.ReadLine();
            }

            Console.WriteLine($"Change: {balance:F2}");
        }
    }
}
